<article class="small">
    <a href="<?php the_permalink(); ?>">
        <div class="img">
            <?php the_post_thumbnail('thumbnail'); ?>
        </div>
        <div class="xtitle">
            <?php the_title(); ?>
        </div>
    </a>
</article>